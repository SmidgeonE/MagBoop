# IMPORTANT INFO

https://youtu.be/JIxhjL_VJ14 - Video to demonstrate.

This mod requires stovepipe. If you do not wish to use it, you can enter the stovepipe config in thunderstores config editor, then disable it. Of course this mod also has a config, where you can change various probabilities to your hearts content.

# MagBoop

This mod is still under development, so may have some issues. 
The sound effects may be a bit whack at times. Some of the triggers for certain magazines aren't aligned well, and some magazines for modded weapons don't make sounds, this isn't something I can easily fix unfortunately.

This mod should work for pretty much every weapon in the game that has a removable magazine.

# Contact

If you wish to support me, my kofi is https://ko-fi.com/smidgeon

If you have any issues / ideas / need help with modding, I am always available on discord in the homebrew server under the name Smidgeon, tag ප bir𝛿 ꧁꧂#9320 (not sure if thunderstoreeven supports those characters).


# Changelog

1.0.8 - Removed debug cube... again...

1.0.7 - If you push the magazine with a strong force, it will decrease the probability that it will not fully go in.
 This is customisable in the config, with probabilities. Fixed many triggers on certain weapon magazines. Added correct mag boop logic for weapons that have magazines that insert above / to the side of the weapon.

1.0.6 - Removed debug cube.

1.0.5 - Added sound effects so its more obvious if the mag is not seated correctly. Fixed bugs with certain capsule-shaped magazines. 

1.0.4 - Disabled weird invisible trigger. Disabled mag booping for weapons that dont need it (i.e. G11)

1.0.3 - Fixed many sources of undeseriable mag boops. added ability to boop slinged weapons. adjusted angle logic for booping. Added check for gripping, to remove unwanted boops.

1.0.2 - Updated so it actually works now.

1.0.1 - More info in readme.

1.0.0 - Initial release.
